package com.example.gemini_gpt

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

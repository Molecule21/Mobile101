class Message {
  final String text;
  final bool isUser;

  Message({required this.text, this.isUser = true});
}

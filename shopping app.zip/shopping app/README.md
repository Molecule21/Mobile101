## flutter_shopping_app

A complete flutter Shopping application project.

### Getting Started

This project is a starting point for a Flutter application.

### Watch:

[![Watch the video](https://cdn.mos.cms.futurecdn.net/8gzcr6RpGStvZFA2qRt4v6.jpg)](https://www.youtube.com/watch?v=LTc2vIA34ds "Everything Is AWESOME")



### A few screenshots:

<img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/login.png?raw=true" width="300" height="650" />   <img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/home.png?raw=true" width="300" height="650" />    <img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/detail.png?raw=true" width="300" height="650" />
<img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/cart.png?raw=true" width="300" height="650" />    <img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/payment.png?raw=true" width="300" height="650" /> <img src="https://github.com/ishaileshmishra/flutter_shopping_app/blob/main/assets/images/receipt.png?raw=true" width="300" height="650" />

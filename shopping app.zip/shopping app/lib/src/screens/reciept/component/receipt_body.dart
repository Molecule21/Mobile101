import 'package:flutter/material.dart';

class RecieptBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

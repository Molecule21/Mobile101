package com.example.flutter_shopping_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

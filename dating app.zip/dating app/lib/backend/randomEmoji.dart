import 'dart:async';
import 'package:animated_background/animated_background.dart';
import 'dart:math';
import 'package:flutter/material.dart';

class AnimatedBack extends StatelessWidget {
  void ma() {
    print("ma");
  }

  const AnimatedBack({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}

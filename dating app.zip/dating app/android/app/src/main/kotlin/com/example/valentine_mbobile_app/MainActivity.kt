package com.example.valentine_mbobile_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

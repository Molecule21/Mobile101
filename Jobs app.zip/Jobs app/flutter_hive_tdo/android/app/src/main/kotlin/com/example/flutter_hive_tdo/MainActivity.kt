package com.example.flutter_hive_tdo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
